# 340B Infrastructure

CloudFormation-based infrastructure for 340B project.

**Environments:** dev, qa, prod

## Resources Deployed

| Stack | Resources |
|-------|-----------|
| Network | VPC, 4 subnets (public + private in 2 AZs), NAT gateway, route tables, security groups, VPC flow logs |
| Compute | ALB (public A/B), target group, ASG, EC2 launch template (Ubuntu 24.04 + nginx), IAM role + instance profile |

## Structure

```
340B-infra/
├── .github/workflows/
│   └── deploy.yml
├── modules/
│   ├── network/vpc.yaml
│   └── compute/alb-asg.yaml
├── environments/
│   ├── dev/parameters.json
│   ├── qa/parameters.json
│   └── prod/parameters.json
├── deploy.sh          # Bash (macOS/Linux)
├── delete.sh          # Bash (macOS/Linux)
├── deploy-gitbash.sh  # Git Bash (Windows - uses jq or Python)
└── delete-gitbash.sh  # Git Bash (Windows - uses jq or Python)
```

## Local Deployment

**Prerequisites:** AWS CLI; jq or Python (for bash/Git Bash)

**Bash (macOS/Linux):**
```bash
./deploy.sh dev Non-prod-workload
./delete.sh dev Non-prod-workload
```

**Git Bash (Windows):**
```bash
./deploy-gitbash.sh dev Non-prod-workload
./delete-gitbash.sh dev Non-prod-workload
```
*Uses jq if available, else Python.*

## GitHub Actions

1. Add secrets: `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`
2. Go to **Actions -> Deploy 340B Infrastructure -> Run workflow**
3. Select environment and action

## Stack Naming

- `bmc340b-{env}-network`
- `bmc340b-{env}-compute`

## Network Layout (2 AZs)

| Subnet | AZ | Type | Purpose |
|--------|-----|------|---------|
| Public A | us-east-1a | Public | ALB |
| Public B | us-east-1b | Public | ALB |
| Private A | us-east-1a | Private | EC2 / ASG |
| Private B | us-east-1b | Private | EC2 / ASG |

## IAM Resources

| Resource | Stack | Purpose |
|----------|-------|---------|
| `{prefix}-{env}-ec2-role` | Compute | EC2 role with SSM + CloudWatch access |
| `{prefix}-{env}-ec2-profile` | Compute | Instance profile attached to launch template |
| FlowLogRole | Network | VPC Flow Logs delivery to CloudWatch |

## Notes

- All IAM roles are self-managed within CloudFormation (no external dependencies)
- EBS volumes are encrypted via launch template (`Encrypted: true`)
- Inspection/Security VPC will be handled by the Network AWS account later
