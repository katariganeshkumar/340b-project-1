# 340B CloudFormation Teardown - VPC, ALB, ASG, EC2
# Deletes stacks in reverse dependency order
# Usage: .\delete.ps1 <environment> [aws-profile]
# Example: .\delete.ps1 dev
# Example: .\delete.ps1 prod Non-prod-workload

param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("dev","qa","prod")]
    [string]$Env,

    [Parameter(Mandatory=$false)]
    [string]$AwsProfile
)

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ParamsFile = Join-Path $ScriptDir "environments\$Env\parameters.json"

if (-not (Test-Path $ParamsFile)) {
    Write-Error "Parameters file not found: $ParamsFile"
    exit 1
}

$Params = Get-Content $ParamsFile | ConvertFrom-Json
$StackPrefix = "bmc340b-$Env"
$Region = if ($Params.Network.Region) { $Params.Network.Region } else { "us-east-1" }

$AwsOpts = @("--region", $Region)
if ($AwsProfile) { $AwsOpts += @("--profile", $AwsProfile) }

Write-Host "=== Deleting 340B infrastructure for environment: $Env in $Region ==="
Write-Host "Stack prefix: $StackPrefix"
Write-Host ""

function Delete-Stack($StackName, $Step) {
    try {
        aws cloudformation describe-stacks @AwsOpts --stack-name $StackName 2>$null | Out-Null
    } catch {
        Write-Host "[$Step] $StackName does not exist, skipping."
        return
    }
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[$Step] $StackName does not exist, skipping."
        return
    }

    Write-Host "[$Step] Deleting $StackName..."
    aws cloudformation delete-stack @AwsOpts --stack-name $StackName
    Write-Host "    Waiting for deletion to complete..."
    aws cloudformation wait stack-delete-complete @AwsOpts --stack-name $StackName 2>$null

    if ($LASTEXITCODE -eq 0) {
        Write-Host "    Deleted $StackName"
        return
    }

    $Status = aws cloudformation describe-stacks @AwsOpts --stack-name $StackName `
        --query "Stacks[0].StackStatus" --output text 2>$null

    if ($Status -eq "DELETE_FAILED") {
        Write-Host "    DELETE_FAILED - retrying with --retain-resources..."
        $FailedResources = aws cloudformation describe-stack-events @AwsOpts --stack-name $StackName `
            --query "StackEvents[?ResourceStatus=='DELETE_FAILED' && ResourceType!='AWS::CloudFormation::Stack'].LogicalResourceId" `
            --output text 2>$null

        if ($FailedResources) {
            Write-Host "    Retaining: $FailedResources"
            $ResourceList = $FailedResources -split "`t"
            aws cloudformation delete-stack @AwsOpts --stack-name $StackName `
                --retain-resources @ResourceList
            aws cloudformation wait stack-delete-complete @AwsOpts --stack-name $StackName 2>$null

            if ($LASTEXITCODE -eq 0) {
                Write-Host "    Deleted $StackName (with retained resources)"
            } else {
                Write-Host "    WARNING: $StackName still failed to delete"
            }
        }
    }
}

# Delete in reverse dependency order: Compute -> Network
Delete-Stack "$StackPrefix-compute" "1/2"
Delete-Stack "$StackPrefix-network" "2/2"

# Clean up orphaned VPC flow log group (uncomment when flow logs are enabled)
# $NamingPrefix = if ($Params.Network.NamingPrefix) { $Params.Network.NamingPrefix } else { "340b" }
# $LogGroup = "/aws/vpc/$NamingPrefix-$Env-flow-logs"
#
# Write-Host ""
# Write-Host "Cleaning up flow log group..."
# $Exists = aws logs describe-log-groups @AwsOpts --log-group-name-prefix $LogGroup `
#     --query "logGroups[?logGroupName=='$LogGroup'].logGroupName" --output text 2>$null
# if ($Exists -eq $LogGroup) {
#     Write-Host "  Deleting log group: $LogGroup"
#     aws logs delete-log-group @AwsOpts --log-group-name $LogGroup 2>$null
# } else {
#     Write-Host "  Log group not found or already deleted."
# }

Write-Host ""
Write-Host "=== Teardown complete for environment: $Env ==="
