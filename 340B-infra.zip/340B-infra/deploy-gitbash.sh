#!/bin/bash
# 340B CloudFormation Deployment - Git Bash (Windows)
# Uses jq or Python - no PowerShell execution policy issues
# Usage: ./deploy-gitbash.sh <environment> [aws-profile]
# Example: ./deploy-gitbash.sh dev Non-prod-workload

set -e

ENV=${1:?Usage: ./deploy-gitbash.sh <dev|qa|prod> [aws-profile]}
AWS_PROFILE=${2:-}
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PARAMS_FILE="${SCRIPT_DIR}/environments/${ENV}/parameters.json"

if [[ ! -f "$PARAMS_FILE" ]]; then
  echo "Error: Parameters file not found: $PARAMS_FILE"
  exit 1
fi

STACK_PREFIX="bmc340b-${ENV}"

# get_param: use jq if available, else Python (for Git Bash without jq)
get_param() {
  local stack=$1
  local key=$2
  if command -v jq &>/dev/null; then
    jq -r --arg s "$stack" --arg k "$key" '.[$s][$k] // empty' "$PARAMS_FILE"
  elif command -v python3 &>/dev/null; then
    python3 -c "import json,sys; d=json.load(open(sys.argv[1])); v=d.get('$stack',{}).get('$key',''); print(v if v is not None else '')" "$PARAMS_FILE" 2>/dev/null
  elif command -v python &>/dev/null; then
    python -c "import json,sys; d=json.load(open(sys.argv[1])); v=d.get('$stack',{}).get('$key',''); print(v if v is not None else '')" "$PARAMS_FILE" 2>/dev/null
  else
    echo "Error: jq or Python required. Install jq: choco install jq" >&2
    exit 1
  fi
}

REGION=$(get_param Network Region)
REGION=${REGION:-us-east-1}

AWS_OPTS="--region $REGION"
[[ -n "$AWS_PROFILE" ]] && AWS_OPTS="$AWS_OPTS --profile $AWS_PROFILE"

ACCOUNT_ID=$(aws sts get-caller-identity $AWS_OPTS --query "Account" --output text)

echo "=== Deploying 340B infrastructure for environment: $ENV in $REGION ==="
echo "Account: $ACCOUNT_ID"
echo ""

# 1. Network (VPC - 2 AZs: public + private per AZ)
echo "[1/2] Deploying Network stack..."
aws cloudformation deploy $AWS_OPTS \
  --template-file "${SCRIPT_DIR}/modules/network/vpc.yaml" \
  --stack-name "${STACK_PREFIX}-network" \
  --parameter-overrides \
    Environment="$ENV" \
    Region="$(get_param Network Region)" \
    NamingPrefix="$(get_param Network NamingPrefix)" \
    VPCCidr="$(get_param Network VPCCidr)" \
    PublicSubnetACidr="$(get_param Network PublicSubnetACidr)" \
    PublicSubnetBCidr="$(get_param Network PublicSubnetBCidr)" \
    PrivateSubnetACidr="$(get_param Network PrivateSubnetACidr)" \
    PrivateSubnetBCidr="$(get_param Network PrivateSubnetBCidr)" \
    AvailabilityZoneA="$(get_param Network AvailabilityZoneA)" \
    AvailabilityZoneB="$(get_param Network AvailabilityZoneB)" \
  --no-fail-on-empty-changeset

# 2. Compute (ALB in public A/B, ASG/EC2 in private A/B)
echo "[2/2] Deploying Compute stack..."
VPC_ID=$(aws cloudformation describe-stacks $AWS_OPTS --stack-name "${STACK_PREFIX}-network" --query "Stacks[0].Outputs[?OutputKey=='VpcId'].OutputValue" --output text)
PUBLIC_SUBNET_A=$(aws cloudformation describe-stacks $AWS_OPTS --stack-name "${STACK_PREFIX}-network" --query "Stacks[0].Outputs[?OutputKey=='PublicSubnetAId'].OutputValue" --output text)
PUBLIC_SUBNET_B=$(aws cloudformation describe-stacks $AWS_OPTS --stack-name "${STACK_PREFIX}-network" --query "Stacks[0].Outputs[?OutputKey=='PublicSubnetBId'].OutputValue" --output text)
PRIVATE_SUBNET_A=$(aws cloudformation describe-stacks $AWS_OPTS --stack-name "${STACK_PREFIX}-network" --query "Stacks[0].Outputs[?OutputKey=='PrivateSubnetAId'].OutputValue" --output text)
PRIVATE_SUBNET_B=$(aws cloudformation describe-stacks $AWS_OPTS --stack-name "${STACK_PREFIX}-network" --query "Stacks[0].Outputs[?OutputKey=='PrivateSubnetBId'].OutputValue" --output text)
ALB_SG=$(aws cloudformation describe-stacks $AWS_OPTS --stack-name "${STACK_PREFIX}-network" --query "Stacks[0].Outputs[?OutputKey=='ALBSecurityGroupId'].OutputValue" --output text)
EC2_SG=$(aws cloudformation describe-stacks $AWS_OPTS --stack-name "${STACK_PREFIX}-network" --query "Stacks[0].Outputs[?OutputKey=='EC2SecurityGroupId'].OutputValue" --output text)

echo "    Resolving latest Ubuntu 24.04 AMI..."
AMI_ID=$(aws ec2 describe-images $AWS_OPTS \
  --owners 099720109477 \
  --filters "Name=name,Values=ubuntu/images/hvm-ssd-gp3/ubuntu-noble-24.04-amd64-server-*" "Name=state,Values=available" \
  --query "sort_by(Images, &CreationDate)[-1].ImageId" --output text)
echo "    AMI: $AMI_ID"

aws cloudformation deploy $AWS_OPTS \
  --template-file "${SCRIPT_DIR}/modules/compute/alb-asg.yaml" \
  --stack-name "${STACK_PREFIX}-compute" \
  --parameter-overrides \
    Environment="$ENV" \
    Region="$(get_param Compute Region)" \
    NamingPrefix="$(get_param Compute NamingPrefix)" \
    InstanceType="$(get_param Compute InstanceType)" \
    MinSize="$(get_param Compute MinSize)" \
    MaxSize="$(get_param Compute MaxSize)" \
    DesiredCapacity="$(get_param Compute DesiredCapacity)" \
    KeyName="$(get_param Compute KeyName)" \
    VpcId="$VPC_ID" \
    PublicSubnetAId="$PUBLIC_SUBNET_A" \
    PublicSubnetBId="$PUBLIC_SUBNET_B" \
    PrivateSubnetAId="$PRIVATE_SUBNET_A" \
    PrivateSubnetBId="$PRIVATE_SUBNET_B" \
    ALBSecurityGroupId="$ALB_SG" \
    EC2SecurityGroupId="$EC2_SG" \
    CertificateArn="" \
    AmiId="$AMI_ID" \
  --capabilities CAPABILITY_NAMED_IAM \
  --no-fail-on-empty-changeset

echo ""
echo "=== Deployment complete ==="
ALB_DNS=$(aws cloudformation describe-stacks $AWS_OPTS --stack-name "${STACK_PREFIX}-compute" --query "Stacks[0].Outputs[?OutputKey=='LoadBalancerDNSName'].OutputValue" --output text)
echo "ALB URL: http://${ALB_DNS}"
