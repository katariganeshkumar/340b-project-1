#!/bin/bash
# 340B CloudFormation Teardown - VPC, ALB, ASG, EC2
# Deletes stacks in reverse dependency order
# Usage: ./delete.sh <environment> [aws-profile]
# Example: ./delete.sh dev
# Example: ./delete.sh prod bmc-cloud-devops

set -e

ENV=${1:?Usage: ./delete.sh <dev|qa|prod> [aws-profile]}
AWS_PROFILE=${2:-}
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PARAMS_FILE="${SCRIPT_DIR}/environments/${ENV}/parameters.json"

if [[ ! -f "$PARAMS_FILE" ]]; then
  echo "Error: Parameters file not found: $PARAMS_FILE"
  exit 1
fi

STACK_PREFIX="bmc340b-${ENV}"
REGION=$(jq -r '.Network.Region // "us-east-1"' "$PARAMS_FILE")

AWS_OPTS="--region $REGION"
[[ -n "$AWS_PROFILE" ]] && AWS_OPTS="$AWS_OPTS --profile $AWS_PROFILE"

echo "=== Deleting 340B infrastructure for environment: $ENV in $REGION ==="
echo "Stack prefix: $STACK_PREFIX"
echo ""

delete_stack() {
  local stack_name=$1
  local step=$2

  if ! aws cloudformation describe-stacks $AWS_OPTS --stack-name "$stack_name" &>/dev/null; then
    echo "[$step] $stack_name does not exist, skipping."
    return 0
  fi

  echo "[$step] Deleting $stack_name..."
  aws cloudformation delete-stack $AWS_OPTS --stack-name "$stack_name"
  echo "    Waiting for deletion to complete..."
  if aws cloudformation wait stack-delete-complete $AWS_OPTS --stack-name "$stack_name" 2>/dev/null; then
    echo "    Deleted $stack_name"
    return 0
  fi

  local status
  status=$(aws cloudformation describe-stacks $AWS_OPTS --stack-name "$stack_name" \
    --query "Stacks[0].StackStatus" --output text 2>/dev/null || echo "")

  if [[ "$status" == "DELETE_FAILED" ]]; then
    echo "    DELETE_FAILED - retrying with --retain-resources..."
    local failed_resources
    failed_resources=$(aws cloudformation describe-stack-events $AWS_OPTS --stack-name "$stack_name" \
      --query "StackEvents[?ResourceStatus=='DELETE_FAILED' && ResourceType!='AWS::CloudFormation::Stack'].LogicalResourceId" \
      --output text 2>/dev/null)

    if [[ -n "$failed_resources" ]]; then
      echo "    Retaining: $failed_resources"
      aws cloudformation delete-stack $AWS_OPTS --stack-name "$stack_name" \
        --retain-resources $failed_resources
      aws cloudformation wait stack-delete-complete $AWS_OPTS --stack-name "$stack_name" 2>/dev/null \
        && echo "    Deleted $stack_name (with retained resources)" \
        || echo "    WARNING: $stack_name still failed to delete"
    fi
  fi
}

# Delete in reverse dependency order: Compute -> Network

delete_stack "${STACK_PREFIX}-compute" "1/2"
delete_stack "${STACK_PREFIX}-network" "2/2"

# Clean up orphaned VPC flow log group (uncomment when flow logs are enabled)
# NAMING_PREFIX=$(jq -r '.Network.NamingPrefix // "340b"' "$PARAMS_FILE")
# LOG_GROUP="/aws/vpc/${NAMING_PREFIX}-${ENV}-flow-logs"
#
# echo ""
# echo "Cleaning up flow log group..."
# if aws logs describe-log-groups $AWS_OPTS --log-group-name-prefix "$LOG_GROUP" --query "logGroups[?logGroupName=='$LOG_GROUP'].logGroupName" --output text 2>/dev/null | grep -q "$LOG_GROUP"; then
#   echo "  Deleting log group: $LOG_GROUP"
#   aws logs delete-log-group $AWS_OPTS --log-group-name "$LOG_GROUP" 2>/dev/null || true
# else
#   echo "  Log group not found or already deleted."
# fi

echo ""
echo "=== Teardown complete for environment: $ENV ==="
