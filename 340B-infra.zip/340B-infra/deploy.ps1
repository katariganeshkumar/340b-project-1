# 340B CloudFormation Deployment - VPC (2 AZs), ALB, ASG, EC2
# Usage: .\deploy.ps1 <environment> [aws-profile]
# Example: .\deploy.ps1 dev
# Example: .\deploy.ps1 prod Non-prod-workload

param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("dev","qa","prod")]
    [string]$Env,

    [Parameter(Mandatory=$false)]
    [string]$AwsProfile
)

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ParamsFile = Join-Path $ScriptDir "environments\$Env\parameters.json"

if (-not (Test-Path $ParamsFile)) {
    Write-Error "Parameters file not found: $ParamsFile"
    exit 1
}

$Params = Get-Content $ParamsFile | ConvertFrom-Json
$StackPrefix = "bmc340b-$Env"
$Region = if ($Params.Network.Region) { $Params.Network.Region } else { "us-east-1" }

$AwsOpts = @("--region", $Region)
if ($AwsProfile) { $AwsOpts += @("--profile", $AwsProfile) }

function Get-Param($Stack, $Key) {
    return $Params.$Stack.$Key
}

$AccountId = aws sts get-caller-identity @AwsOpts --query "Account" --output text
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "=== Deploying 340B infrastructure for environment: $Env in $Region ==="
Write-Host "Account: $AccountId"
Write-Host ""

# 1. Network (VPC - 2 AZs: public + private per AZ)
Write-Host "[1/2] Deploying Network stack..."
aws cloudformation deploy @AwsOpts `
    --template-file "$ScriptDir\modules\network\vpc.yaml" `
    --stack-name "$StackPrefix-network" `
    --parameter-overrides `
        "Environment=$Env" `
        "Region=$(Get-Param Network Region)" `
        "NamingPrefix=$(Get-Param Network NamingPrefix)" `
        "VPCCidr=$(Get-Param Network VPCCidr)" `
        "PublicSubnetACidr=$(Get-Param Network PublicSubnetACidr)" `
        "PublicSubnetBCidr=$(Get-Param Network PublicSubnetBCidr)" `
        "PrivateSubnetACidr=$(Get-Param Network PrivateSubnetACidr)" `
        "PrivateSubnetBCidr=$(Get-Param Network PrivateSubnetBCidr)" `
        "AvailabilityZoneA=$(Get-Param Network AvailabilityZoneA)" `
        "AvailabilityZoneB=$(Get-Param Network AvailabilityZoneB)" `
    --no-fail-on-empty-changeset
    # FlowLog (uncomment when ready to enable, also uncomment in vpc.yaml and parameters.json)
    # "FlowLogRetentionDays=$(Get-Param Network FlowLogRetentionDays)" `
    # --capabilities CAPABILITY_NAMED_IAM `

if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

# 2. Compute (ALB in public A/B, ASG/EC2 in private A/B)
Write-Host "[2/2] Deploying Compute stack..."
$VpcId = aws cloudformation describe-stacks @AwsOpts --stack-name "$StackPrefix-network" --query "Stacks[0].Outputs[?OutputKey=='VpcId'].OutputValue" --output text
$PublicSubnetA = aws cloudformation describe-stacks @AwsOpts --stack-name "$StackPrefix-network" --query "Stacks[0].Outputs[?OutputKey=='PublicSubnetAId'].OutputValue" --output text
$PublicSubnetB = aws cloudformation describe-stacks @AwsOpts --stack-name "$StackPrefix-network" --query "Stacks[0].Outputs[?OutputKey=='PublicSubnetBId'].OutputValue" --output text
$PrivateSubnetA = aws cloudformation describe-stacks @AwsOpts --stack-name "$StackPrefix-network" --query "Stacks[0].Outputs[?OutputKey=='PrivateSubnetAId'].OutputValue" --output text
$PrivateSubnetB = aws cloudformation describe-stacks @AwsOpts --stack-name "$StackPrefix-network" --query "Stacks[0].Outputs[?OutputKey=='PrivateSubnetBId'].OutputValue" --output text
$AlbSg = aws cloudformation describe-stacks @AwsOpts --stack-name "$StackPrefix-network" --query "Stacks[0].Outputs[?OutputKey=='ALBSecurityGroupId'].OutputValue" --output text
$Ec2Sg = aws cloudformation describe-stacks @AwsOpts --stack-name "$StackPrefix-network" --query "Stacks[0].Outputs[?OutputKey=='EC2SecurityGroupId'].OutputValue" --output text

Write-Host "    Resolving latest Ubuntu 24.04 AMI..."
$AmiId = aws ec2 describe-images @AwsOpts `
    --owners 099720109477 `
    --filters "Name=name,Values=ubuntu/images/hvm-ssd-gp3/ubuntu-noble-24.04-amd64-server-*" "Name=state,Values=available" `
    --query "sort_by(Images, &CreationDate)[-1].ImageId" --output text
Write-Host "    AMI: $AmiId"

aws cloudformation deploy @AwsOpts `
    --template-file "$ScriptDir\modules\compute\alb-asg.yaml" `
    --stack-name "$StackPrefix-compute" `
    --parameter-overrides `
        "Environment=$Env" `
        "Region=$(Get-Param Compute Region)" `
        "NamingPrefix=$(Get-Param Compute NamingPrefix)" `
        "InstanceType=$(Get-Param Compute InstanceType)" `
        "MinSize=$(Get-Param Compute MinSize)" `
        "MaxSize=$(Get-Param Compute MaxSize)" `
        "DesiredCapacity=$(Get-Param Compute DesiredCapacity)" `
        "KeyName=$(Get-Param Compute KeyName)" `
        "VpcId=$VpcId" `
        "PublicSubnetAId=$PublicSubnetA" `
        "PublicSubnetBId=$PublicSubnetB" `
        "PrivateSubnetAId=$PrivateSubnetA" `
        "PrivateSubnetBId=$PrivateSubnetB" `
        "ALBSecurityGroupId=$AlbSg" `
        "EC2SecurityGroupId=$Ec2Sg" `
        "CertificateArn=" `
        "AmiId=$AmiId" `
    --capabilities CAPABILITY_NAMED_IAM `
    --no-fail-on-empty-changeset

if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host ""
Write-Host "=== Deployment complete ==="
$AlbDns = aws cloudformation describe-stacks @AwsOpts --stack-name "$StackPrefix-compute" --query "Stacks[0].Outputs[?OutputKey=='LoadBalancerDNSName'].OutputValue" --output text
Write-Host "ALB URL: http://$AlbDns"
