#!/bin/bash
# 340B CloudFormation Teardown - Git Bash (Windows)
# Usage: bash delete-gitbash.sh <environment> [aws-profile]
# Example: bash delete-gitbash.sh dev Non-prod-workload

ENV=${1:?Usage: bash delete-gitbash.sh <dev|qa|prod> [aws-profile]}
AWS_PROFILE=${2:-}
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PARAMS_FILE="${SCRIPT_DIR}/environments/${ENV}/parameters.json"

if [[ ! -f "$PARAMS_FILE" ]]; then
  echo "Error: Parameters file not found: $PARAMS_FILE"
  exit 1
fi

STACK_PREFIX="bmc340b-${ENV}"

# Detect JSON parser: jq or python
if command -v jq &>/dev/null; then
  get_param() {
    jq -r --arg s "$1" --arg k "$2" '.[$s][$k] // empty' "$PARAMS_FILE"
  }
elif command -v python &>/dev/null; then
  get_param() {
    python -c "import json,sys; d=json.load(open(sys.argv[1])); v=d.get(sys.argv[2],{}).get(sys.argv[3],''); print('' if v is None else v)" "$PARAMS_FILE" "$1" "$2"
  }
elif command -v python3 &>/dev/null; then
  get_param() {
    python3 -c "import json,sys; d=json.load(open(sys.argv[1])); v=d.get(sys.argv[2],{}).get(sys.argv[3],''); print('' if v is None else v)" "$PARAMS_FILE" "$1" "$2"
  }
else
  echo "Error: jq or Python is required."
  exit 1
fi

REGION=$(get_param Network Region)
REGION=${REGION:-us-east-1}

AWS_OPTS="--region $REGION"
if [[ -n "$AWS_PROFILE" ]]; then
  AWS_OPTS="$AWS_OPTS --profile $AWS_PROFILE"
fi

echo "=== Deleting 340B infrastructure for environment: $ENV in $REGION ==="
echo "Stack prefix: $STACK_PREFIX"
echo ""

delete_stack() {
  local stack_name=$1
  local step=$2

  if ! aws cloudformation describe-stacks $AWS_OPTS --stack-name "$stack_name" 2>/dev/null 1>/dev/null; then
    echo "[$step] $stack_name does not exist, skipping."
    return 0
  fi

  echo "[$step] Deleting $stack_name..."
  aws cloudformation delete-stack $AWS_OPTS --stack-name "$stack_name"
  echo "    Waiting for deletion to complete..."
  if aws cloudformation wait stack-delete-complete $AWS_OPTS --stack-name "$stack_name" 2>/dev/null; then
    echo "    Deleted $stack_name"
    return 0
  fi

  local status
  status=$(aws cloudformation describe-stacks $AWS_OPTS --stack-name "$stack_name" \
    --query "Stacks[0].StackStatus" --output text 2>/dev/null || echo "")

  if [[ "$status" == "DELETE_FAILED" ]]; then
    echo "    DELETE_FAILED - retrying with --retain-resources..."
    local failed_resources
    failed_resources=$(aws cloudformation describe-stack-events $AWS_OPTS --stack-name "$stack_name" \
      --query "StackEvents[?ResourceStatus=='DELETE_FAILED' && ResourceType!='AWS::CloudFormation::Stack'].LogicalResourceId" \
      --output text 2>/dev/null)

    if [[ -n "$failed_resources" ]]; then
      echo "    Retaining: $failed_resources"
      aws cloudformation delete-stack $AWS_OPTS --stack-name "$stack_name" \
        --retain-resources $failed_resources
      aws cloudformation wait stack-delete-complete $AWS_OPTS --stack-name "$stack_name" 2>/dev/null \
        && echo "    Deleted $stack_name (with retained resources)" \
        || echo "    WARNING: $stack_name still failed to delete"
    fi
  fi
}

# Delete in reverse dependency order: Compute -> Network
delete_stack "${STACK_PREFIX}-compute" "1/2"
delete_stack "${STACK_PREFIX}-network" "2/2"

echo ""
echo "=== Teardown complete for environment: $ENV ==="
